/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClasesEInterfaces;

/**
 *
 * @author cristolagos
 */
public interface getId {
    public abstract int getId();
    
}
